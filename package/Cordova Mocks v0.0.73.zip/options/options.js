angular.module('chromeApp', [
    'ngMaterial'
])

    .run(function () {


    })

    .config(function () {


    })

    .controller("AppCtrl", function () {

    })

    .controller("SidenavCtrl", function ($scope) {

        $scope.options = [
            {name: "Device"},
            {name: ""}
        ];


    });
